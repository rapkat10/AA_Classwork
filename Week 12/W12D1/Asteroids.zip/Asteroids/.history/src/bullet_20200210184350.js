function Bullet (spec) {
  MovingOb  
};





module.exports = Bullet;