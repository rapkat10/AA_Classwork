function Ship() {};

Ship.RADIUS = 15;
Ship.COLOR = "#ff0000"


module.exports = Ship;