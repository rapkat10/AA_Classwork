const utils = require("./utils");

function Asteroid(spec) {
  
};



module.exports = Asteroid;