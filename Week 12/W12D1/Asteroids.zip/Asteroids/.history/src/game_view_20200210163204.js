function GameView () {
    
}