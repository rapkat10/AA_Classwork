function Game () {}

Game.DIM_X
Game.DIM_Y


module.exports = Game;