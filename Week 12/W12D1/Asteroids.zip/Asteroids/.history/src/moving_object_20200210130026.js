function movingObject() {
  
};