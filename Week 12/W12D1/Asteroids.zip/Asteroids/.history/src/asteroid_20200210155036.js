const utils = require("./utils");

function Asteroid(spec) {
  utils.inherits(Asteroid, Movin)
};



module.exports = Asteroid;