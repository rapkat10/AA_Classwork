function GameView () {

}


module.exports = GameView;