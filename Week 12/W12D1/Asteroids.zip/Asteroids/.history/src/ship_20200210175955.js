function Ship() {};

module.exports = 