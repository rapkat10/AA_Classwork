function Game () {}

Game.DIM_

module.exports = Game;