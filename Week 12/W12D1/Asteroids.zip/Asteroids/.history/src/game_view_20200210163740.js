function GameView (ctx) {
  this.ctx = ctx;

}

GameView.method()


module.exports = GameView;