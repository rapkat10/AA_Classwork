Function.prototype.method = function (name, func) {
  this.prototype[name] = func;
  return this;
};

const Utils = {};

exports.Vector = function Vector() {}
}

module.exports = Utils;