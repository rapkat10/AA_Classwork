function Asteroid(spec) {
    
}



module.exports = Asteroid;