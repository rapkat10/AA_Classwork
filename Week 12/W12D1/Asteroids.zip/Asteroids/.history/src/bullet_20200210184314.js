function Bullet (spec) {
  
};



module.exports = Bullet;