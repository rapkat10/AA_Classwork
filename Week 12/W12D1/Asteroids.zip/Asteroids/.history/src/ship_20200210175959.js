function Ship() {};


module.exports = Ship;