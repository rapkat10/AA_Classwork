const Game = require("./game")
function GameView (ctx) {
  this.ctx = ctx;

}

GameView.method("start", () => {

});


module.exports = GameView;