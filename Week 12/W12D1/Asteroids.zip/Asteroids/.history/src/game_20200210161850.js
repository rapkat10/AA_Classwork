function Game () {}

Game.DIM_X = 
Game.DIM_Y
Game.NUM_ASTEROIDS

module.exports = Game;