function MovingObject(spec) {
  this.pos = spec.pos;
  this.vel = spec.vel;
  this.radius = spec.radius;
  this.color = spec.color;
};

module.exports MovingObject;


