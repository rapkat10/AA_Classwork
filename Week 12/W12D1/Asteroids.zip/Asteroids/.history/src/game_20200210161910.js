function Game () {}

Game.DIM_X = 600;
Game.DIM_Y = 400;
Game.NUM_ASTEROIDS

module.exports = Game;