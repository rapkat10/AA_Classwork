const 

function Asteroid(spec) {
    
};



module.exports = Asteroid;