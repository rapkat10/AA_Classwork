console.log("Webpack is working!")

const MovingObject = require("./moving_object");